﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesignPatterns.Behavior_Observer
{
    /// <summary>
    /// Subject to be observed
    /// </summary>
    public abstract class Subject
    {
        List<Observer> itsObserverList = new List<Observer>();
        public void AttachObserver(Observer theObserver)
        {
            itsObserverList.Add(theObserver);
        }

        public void Detach(Observer theObserver)
        {
            itsObserverList.Remove(theObserver);
        }

        /// <summary>
        /// When internal elements of the subject change, notify all subscribers.
        /// </summary>
        public void Notify()
        {
            foreach (Observer aObserver in itsObserverList)
            {
                aObserver.Update(this);
            }
        }
    }

    public class ConcreteSubject_WeatherStation : Subject
    {
        public int itsTemperature = 0;
        public void ChangeTemperature(int theTemp)
        {
            itsTemperature = theTemp;
            this.Notify();
        }

        public int GetTemperature()
        {
            return itsTemperature;
        }
    }

    /// <summary>
    /// Base observer
    /// </summary>
    public abstract class Observer
    {
        public abstract void Update(Subject theSubject);
    }

    /// <summary>
    /// Concrete observer
    /// </summary>
    public class ConcreteObserver : Observer
    {
        Label itsLabel = null;
        public ConcreteObserver(System.Windows.Forms.Label aLabel)
        {
            itsLabel = aLabel;
        }
        Subject itsSubject = null;
        int temperature = 0;
        public override void Update(Subject theSubject)
        {
            if (theSubject is ConcreteSubject_WeatherStation)
            {
                ConcreteSubject_WeatherStation aStation = theSubject as ConcreteSubject_WeatherStation;
                temperature = aStation.GetTemperature();
                itsLabel.Invoke(new MethodInvoker(() =>
                {
                    itsLabel.Text = temperature.ToString();
                    itsLabel.Update();
                }));
            }

        }
    }
}
