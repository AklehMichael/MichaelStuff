﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns
{
    
    /// <summary>
    /// Mike Notes: 
    /// 1. Strategy Pattern: Defines a family of algorithms, encapsulate each one, and make them interchangeable. Strategy lets the algorithm vary independently from clients that use it.
    /// 2. Encapsulates "types of strategies".
    /// 3. A good use time to use this pattern is when a class heiarchy has a common method that needs to be implemented, but some of these classes implement them using strategy A, some Strategy B, and some even strategy C and so on.
    /// </summary>
    /// Problem that is fixed: Removes the burden of copy pasting implementation details of reusable functionality. Example: Person class has a Talk() method that everyone uses. But, many people talk differntly, while many talk using the same "Strategy". Instead of overriding  Talk() method, define TalkingStrategys.
    /// TalkingStrategyA implements soft spoken way of speaking, TalkingStrategyB, implements outspoken way of people talking. Now you can assign the type of strategy that you want the Person Object to use via contructor or other alternatives.


    public class StrategyClientDriver : IBehavioralStrategyPattern
    {
        IBehavioralStrategyPattern itsPattern = null;
        public StrategyClientDriver (IBehavioralStrategyPattern theStrategy)
        {
            itsPattern = theStrategy;
        }
       
        public string StrategyType()
        {
            return itsPattern.StrategyType();
        }
    }

    public interface IBehavioralStrategyPattern
    {
        string StrategyType();
    }

    public class strategyTypeA:IBehavioralStrategyPattern
    {       
        public string StrategyType()
        {
            return "Strategy Type A";
        }
    }

    public class strategyTypeB : IBehavioralStrategyPattern
    {
        public string StrategyType()
        {
            return "Strategy Type B";
        }
    }

    public class strategyTypeC : IBehavioralStrategyPattern
    {
        public string StrategyType()
        {
            return "Strategy Type C";
        }
    }

}
