﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns.Creational_Factory_Method
{
    /// <summary>
    /// Mike's Notes
    /// 1. Factory Method pattern is a good way to encapsulate the business logic for constructing objects.
    /// 2. You can create many differnt Factories ( or creators) which contain differnt business logic or ways of instantiating a product.
    /// 3. You can create many differnt products
    /// </summary>
    /// Problem that is fixed: Creates a standardized way of instantiating a group of relatable objects, which makes life easy for the clients that use the factory. Also encapsulates all business logic inside the creator's factory method.


    #region Example 1
    public interface ICreator
    {
        BreakfestProduct FactoryMethod(int theChosenProduct);
    }
    /// <summary>
    /// Construct a breakfest product based on some business logic.
    /// </summary>
    public class BreakfestFactoryCreator : ICreator
    {
        /// <summary>
        /// Contains business logic for constructing objects.
        /// </summary>
        /// <param name="theTypeOfBreakfest"></param>
        /// <returns></returns>
        public BreakfestProduct FactoryMethod(int theTypeOfBreakfest)
        {
            BreakfestProduct aProduct = null;
            if (theTypeOfBreakfest == 0)
                aProduct = new ProductA();
            else if (theTypeOfBreakfest == 1)
                aProduct = new ProductB();
            else if (theTypeOfBreakfest == 2)
                aProduct = new ProductC();
            return aProduct;
        }
    }

    /// <summary>
    /// Contains different business logic for the construction of an breakfest object
    /// </summary>
    public class BreakfestFactoryCreator2 : ICreator
    {
        public BreakfestProduct FactoryMethod(int theTypeOfBreakfest)
        {
            BreakfestProduct aProduct = null;
            if (theTypeOfBreakfest == 2)
                aProduct = new ProductA();
            else if (theTypeOfBreakfest == 1)
                aProduct = new ProductB();
            else if (theTypeOfBreakfest == 0)
                aProduct = new ProductC();
            return aProduct;
        }
    }

    /// <summary>
    /// Contains a bunch of differnt ways to construct a "Breakfest Product"
    /// </summary>
    public abstract class BreakfestProduct
    {
        protected string itsBreakfestFood = string.Empty;
        protected string itsBreakfestDrink = string.Empty;
        public abstract string CreateBreakfest();
    }

    public class ProductA : BreakfestProduct
    {
        public ProductA()
        {
            this.itsBreakfestDrink = "Eggs and Bacon";
            this.itsBreakfestFood = "Orange Juice";
        }

        public override string CreateBreakfest()
        {
            return this.itsBreakfestFood + " and " + this.itsBreakfestDrink; ;
        }
    }

    public class ProductB : BreakfestProduct
    {
        public ProductB()
        {
            this.itsBreakfestDrink = "Toast";
            this.itsBreakfestFood = "soup";
        }
        public override string CreateBreakfest()
        {
            return "Toast and soup";
        }
    }

    public class ProductC : BreakfestProduct
    {
        public ProductC()
        {
            this.itsBreakfestDrink = "Milk";
            this.itsBreakfestFood = "Cereal";
        }
        public override string CreateBreakfest()
        {
            return this.itsBreakfestFood + " and " + this.itsBreakfestDrink;
        }
    }
    #endregion

    #region Example 2
    /// <summary>
    /// Product
    /// </summary>
    public interface Level
    {
        public string LevelDesign();
    }

    /// <summary>
    /// Concrete Product, Snow Level
    /// </summary>
    public class SnowLevel : Level
    {
        public string LevelDesign()
        {
            return "Snowly Level object";
        }
    }

    /// <summary>
    /// Concrete Product, Lava Level
    /// </summary>
    public class LavaLevel : Level
    {
        public string LevelDesign()
        {
            return "Lava Lavel object";
        }
    }

    /// <summary>
    /// Level Creator interface
    /// </summary>
    public interface LevelCreator
    {
        public Level FactoryMethod_GetLevel();
    }

    /// <summary>
    /// Contains business logic, on how a object should be instantiated or which object should be created
    /// </summary>
    public class CreateLevel : LevelCreator
    {
        string itsLevelChoice = string.Empty;
        public CreateLevel(string theDesiredLevelChoice)
        {

        }
        public Level FactoryMethod_GetLevel()
        {
            if (itsLevelChoice == "Snow")
                return new SnowLevel();
            else if (itsLevelChoice == "Lava")
                return new LavaLevel();
            else return null;
        }
    }
    #endregion
}
