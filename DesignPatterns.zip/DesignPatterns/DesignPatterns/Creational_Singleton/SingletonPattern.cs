﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns.Creational_Singleton
{
    /// <summary>
    /// Mike Notes:
    /// 1. Creational Singleton Pattern: Ensures that a class can only have a single instance and has a global point of access.
    /// 2. Maybe this can be used for single player games? A single object should be used that contains the game loop?
    /// </summary>
    class SingletonPattern
    {
        private static SingletonPattern itsInstance = null;
        private SingletonPattern() { }

        public static SingletonPattern GetInstance()
        {
            if (itsInstance == null)
            {
                itsInstance = new SingletonPattern();
            }
            return itsInstance;
        }

        public string SaySomething()
        {
            return "Hello From Singleton Pattern";
        }
    }
}
