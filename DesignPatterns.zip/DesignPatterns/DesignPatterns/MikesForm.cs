﻿using DesignPatterns.Behavior_Observer;
using DesignPatterns.Creational_Factory_Method;
using DesignPatterns.Creational_Singleton;
using DesignPatterns.Structural_Decorator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesignPatterns
{
    public partial class MikesForm : Form
    {
        Button itsStrategyButton = new Button();
        Label itsStratgeyLabel = new Label();

        Button itsSingletonButton = new Button();
        Label itsSingletonLabel = new Label();

        Button itsCreationalMethodButton = new Button();
        Label itsCreationalMethodLabel = new Label();

        Button itsDecoratorButton = new Button();
        Label itsDecoratorLabel = new Label();

        Button itsObserverButton = new Button();
        Label itsObserverLabel = new Label();
        public MikesForm()
        {
            //InitializeComponent();
            InitializeMikesForm();
        }

        public void InitializeMikesForm()
        {
            // Suspend layout logic
            this.SuspendLayout();
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "MikesForm";
            this.Text = "Form1";

            // Behavior - Stratgey Pattern -----------------------------------
            // Strategy Button
            this.itsStrategyButton.Name = "StrategyButton";
            this.itsStrategyButton.Location = new System.Drawing.Point(0, 0);
            this.itsStrategyButton.Size = new System.Drawing.Size(75, 25);
            this.itsStrategyButton.Text = "Strategy Button";
            this.itsStrategyButton.Click += new EventHandler(itsStrategyButton_Handler);

            // Strategy Label
            this.itsStratgeyLabel.Name = "StrategyLabel";
            this.itsStratgeyLabel.Location = new System.Drawing.Point(100, 5);
            this.itsStratgeyLabel.Size = new System.Drawing.Size(200, 25);


            this.Controls.Add(this.itsStrategyButton);
            this.Controls.Add(this.itsStratgeyLabel);
            // --------------------------------------------------------------

            // Creational - Singleton Pattern -------------------------------
            // Singleton Button
            this.itsSingletonButton.Name = "SingletonButton";
            this.itsSingletonButton.Location = new System.Drawing.Point(0, 45);
            this.itsSingletonButton.Size = new System.Drawing.Size(75, 25);
            this.itsSingletonButton.Text = "Singleton Button";
            this.itsSingletonButton.Click += new EventHandler(itsSingleton_Handler);

            // Singleton Label
            this.itsSingletonLabel.Name = "SingletonLabel";
            this.itsSingletonLabel.Location = new System.Drawing.Point(100, 45);
            this.itsSingletonLabel.Size = new System.Drawing.Size(200, 25);
            this.Controls.Add(this.itsSingletonButton);
            this.Controls.Add(this.itsSingletonLabel);

            // Creational -- Factory Method Pattern
            this.itsCreationalMethodButton.Name = "Creational Method";
            this.itsCreationalMethodButton.Location = new System.Drawing.Point(0, 85);
            this.itsCreationalMethodButton.Size = new System.Drawing.Size(75, 25);
            this.itsCreationalMethodButton.Text = "Creational Method";
            this.itsCreationalMethodButton.Click += new EventHandler(itsCreeationalMethod_Handler);

            //Creational Method Label
            this.itsCreationalMethodLabel.Name = "Creational Method Label";
            this.itsCreationalMethodLabel.Location = new System.Drawing.Point(100, 85);
            this.itsCreationalMethodLabel.Size = new System.Drawing.Size(200, 25);
            this.Controls.Add(this.itsCreationalMethodButton);
            this.Controls.Add(this.itsCreationalMethodLabel);

            // Structural Decorator
            this.itsDecoratorButton.Name = "Decorator";
            this.itsDecoratorButton.Location = new System.Drawing.Point(0, 125);
            this.itsDecoratorButton.Size = new System.Drawing.Size(75, 25);
            this.itsDecoratorButton.Text = "Decorator";
            this.itsDecoratorButton.Click += new EventHandler(itsDecoratorButton_Handler);

            //Decorator Label
            this.itsDecoratorLabel.Name = "Decorator Label";
            this.itsDecoratorLabel.Location = new System.Drawing.Point(100, 125);
            this.itsDecoratorLabel.Size = new System.Drawing.Size(600, 25);
            this.Controls.Add(this.itsDecoratorButton);
            this.Controls.Add(this.itsDecoratorLabel);

            // Observer
            this.itsObserverButton.Name = "Observer";
            this.itsObserverButton.Location = new System.Drawing.Point(0, 165);
            this.itsObserverButton.Size = new System.Drawing.Size(75, 25);
            this.itsObserverButton.Text = "Observer";
            this.itsObserverButton.Click += new EventHandler(itsObserverButton_Handler);

            this.itsObserverLabel.Name = "Observer Label";
            this.itsObserverLabel.Location = new System.Drawing.Point(100, 165);
            this.itsObserverLabel.Size = new System.Drawing.Size(600, 25);
            this.Controls.Add(this.itsObserverButton);
            this.Controls.Add(this.itsObserverLabel);

            // Resume Layout logic
            this.ResumeLayout(true);

        }

        public void itsStrategyButton_Handler(object sender, EventArgs e)
        {
            IBehavioralStrategyPattern aPattern = null;
            Random aRand = new Random();
            int aStragey = aRand.Next(0,3);
            if (aStragey == 0)
                aPattern = new strategyTypeA();
            else if (aStragey == 1)
                aPattern = new strategyTypeB();
            else if (aStragey == 2)
                aPattern = new strategyTypeC();

            StrategyClientDriver aClient = new StrategyClientDriver(aPattern);
            itsStratgeyLabel.Text = aClient.StrategyType();
        }

        public void itsSingleton_Handler(object sender, EventArgs e)
        {
            itsSingletonLabel.Text = SingletonPattern.GetInstance().SaySomething();
        }

        public void itsCreeationalMethod_Handler(object sender, EventArgs e)
        {
            Random aRand = new Random();
            int aInstance = aRand.Next(0, 3);
            if(aInstance == 0) // Use BreakfestCreator's business logic
            {
                BreakfestFactoryCreator aCreator = new BreakfestFactoryCreator();
                BreakfestProduct aProduct = aCreator.FactoryMethod(aInstance);
                itsCreationalMethodLabel.Text = aProduct.CreateBreakfest();
            }
            else // use differnt business logic to create a breakfest object.
            {
                BreakfestFactoryCreator2 aCreator = new BreakfestFactoryCreator2();
                BreakfestProduct aProduct = aCreator.FactoryMethod(aInstance);
                itsCreationalMethodLabel.Text = aProduct.CreateBreakfest();
            }
        }

        public void itsDecoratorButton_Handler(object sender, EventArgs e)
        {
          // Pizza aPizza = new Pizza();
          // AddOlivesDecorator aOliveDecorator = new AddOlivesDecorator();
          // aOliveDecorator.SetPizza(aPizza);
          // AddExtraCheeseDecorator aAddExtraCheeseDecorator = new AddExtraCheeseDecorator();
          // aAddExtraCheeseDecorator.SetPizza(aOliveDecorator);
          // itsDecoratorLabel.Text = aAddExtraCheeseDecorator.GetPizzaType();

            IceCream aIceCream = new IceCream();
            SprinklesDecorator sprinklesDecorator = new SprinklesDecorator();
            sprinklesDecorator.SetIceCream(aIceCream); // sprinkles decorator has an instance of icecream
            ChocolateSyrupDecorator chocolateSyrupDecorator = new ChocolateSyrupDecorator(); 
            chocolateSyrupDecorator.SetIceCream(sprinklesDecorator); // ChocolateSyrup decorator instance has an instance of sprinkles decorator. 
            itsDecoratorLabel.Text = chocolateSyrupDecorator.GetIceCreamType(); // All operations of proceding IceCream objects are invoked

        }

        public void itsObserverButton_Handler(object sender, EventArgs e)
        {
            ConcreteObserver aObserver = new ConcreteObserver(this.itsObserverLabel);
            ConcreteSubject_WeatherStation aSubject = new ConcreteSubject_WeatherStation();
            aSubject.AttachObserver(aObserver);
            aSubject.ChangeTemperature(100);
            System.Threading.Thread.Sleep(2000);
            aSubject.ChangeTemperature(200);

        }



    }
}
