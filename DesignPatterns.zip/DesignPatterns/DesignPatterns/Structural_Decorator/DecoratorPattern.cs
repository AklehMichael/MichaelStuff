﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace DesignPatterns.Structural_Decorator
{
    /// <summary>
    /// Base Component 
    /// </summary>
    public interface IPizza
    {
        public string GetPizzaType();
    }

    /// <summary>
    /// Concrete Component
    /// </summary>
    public class Pizza : IPizza
    {
        public string GetPizzaType()
        {
            return "This is a normal Pizza ";
        }
    }

    /// <summary>
    /// Base Decorator
    /// </summary>
    public abstract class BasePizzaDecorator : IPizza
    {
        protected IPizza itsPizza;
        public void SetPizza(IPizza thePizza)
        {
            itsPizza = thePizza;
        }

        public virtual string GetPizzaType()
        {
            return itsPizza.GetPizzaType();
        }
    }

    public class AddOlivesDecorator : BasePizzaDecorator
    {
        public override string GetPizzaType()
        {
            return itsPizza.GetPizzaType() + "with olives ";
        }
    }

    public class AddExtraCheeseDecorator : BasePizzaDecorator
    {
        public override string GetPizzaType()
        {
            return itsPizza.GetPizzaType() + "with extra cheese ";
        }
    }

    #region Example # 2

    /// <summary>
    /// Define Base Compomemt
    /// </summary>
    public interface IIceCream
    {
        string GetIceCreamType();
    }

    /// <summary>
    /// Concrete component
    /// </summary>
    public class IceCream : IIceCream
    {
        public string GetIceCreamType()
        {
            return "Normal Ice cream";
        }
    }

    /// <summary>
    /// Base Decorator that other decorators inherit from
    /// </summary>
    public abstract class BaseIceCreamDecorator : IIceCream
    {
        protected IIceCream itsIceCream;
        public void SetIceCream(IIceCream iceCream)
        {
            itsIceCream = iceCream;
        }
        public virtual string GetIceCreamType()
        {
            return itsIceCream.GetIceCreamType();
        }
    }

    /// <summary>
    /// Concrete decorator A
    /// </summary>
    public class SprinklesDecorator : BaseIceCreamDecorator
    {
        public override string GetIceCreamType()
        {
            return itsIceCream.GetIceCreamType() + " with sprinkles";
        }
    }

    /// <summary>
    /// Concrete Decorator B
    /// </summary>
    public class ChocolateSyrupDecorator : BaseIceCreamDecorator
    {
        public override string GetIceCreamType()
        {
            return itsIceCream.GetIceCreamType() + " with chocolate syrup";
        }
    }
    #endregion
}

